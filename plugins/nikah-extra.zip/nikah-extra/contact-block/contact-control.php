<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class nikah_contact_form extends Widget_Base {

	public function get_name() {
		return 'nikah-contact-form';
	}

	public function get_title() {
		return __( 'Form Builder', 'nikah' );
	}

	public function get_icon() {
		return 'eicon-form-horizontal';
	}

	public function get_categories() {
		return [ 'nikah-general-category' ];
	}

	protected function register_controls() {

		/*===========FORM GENERAL SETTING=============*/

		$this->start_controls_section(
			'section_nikah_contact_form_general_control',
			[
				'label' => __( 'Form Setting', 'nikah' ),
			]
		);

		$this->add_control(
			'form_select',
			[
				'label' => __( 'Contact Form', 'nikah' ),
				'type' => Controls_Manager::SELECT,
				'default' => [],
				'options' => nikah_contactform_temp(),
				'description' => __( 'List of your available contact form template.', 'nikah' ),
			]
		);

		$this->end_controls_section();

	}

	protected function render() {

		$instance = $this->get_settings();

		include ( plugin_dir_path(__FILE__).'tpl/contact-block.php' );

	}

	protected function content_template() {}

	public function render_plain_content( $instance = [] ) {

	}

}

Plugin::instance()->widgets_manager->register_widget_type( new nikah_contact_form() );