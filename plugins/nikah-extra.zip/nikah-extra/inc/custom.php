<?php

function nikah_slider_temp() {
	$shortcodes = array();
	if (class_exists('RevSliderGlobals')) {
		$sld = new RevSlider();
		$sliders = $sld->getArrSliders();
		if(!empty($sliders)){
			$first = true;
			foreach($sliders as $slider){
				$name = $slider->getParam('alias','false');
				if($name != 'false'){
					$shortcodes[$slider->getID()] = $name;
					$first = false;
				}
			}
		}
	}

	return $shortcodes;

	wp_reset_postdata();
}

function nikah_contactform_temp() {
	$wpcf7_array = array();

	$args = array(
	    'post_type' => 'wpcf7_contact_form',
	);
	
	$wpcf7 = get_posts($args);

	foreach( $wpcf7 as $post ) { setup_postdata( $post );
	    $wpcf7_array[$post->ID] = $post->post_title;
	} 

	return $wpcf7_array;

    wp_reset_postdata();
}

function nikah_get_category() {

$output_categories = array('All');
$categories = get_categories();

  foreach($categories as $category) { 
	 $output_categories[$category->cat_ID] = $category->name;

}
return $output_categories;
}

function nikah_porto_category() {

global $post;
$output_categories2 = array();
$category_terms = get_terms('portfolio-category');

	foreach($category_terms as $category) {
		$output_categories2[$category->term_id] = $category->name;
	}
	return $output_categories2;
}

function nikah_order_by() {
$nikah_orderby = array(

	'none'                  => 'none',
	'ID'                    => 'ID',
	'author'                => 'Author',
	'title'                 => 'Title',
	'name'                  => 'Name',
	'type'                  => 'Type',
	'date'                  => 'Date',
	'modified'              => 'Modifiede Time',
	'parent'                => 'Parent',
	'rand'                  => 'Random',
	'comment_count' => 'Total Comment',
	'menu_order'    => 'Menu Order',
	'meta_value'    => 'Popular'

);

return $nikah_orderby;
}

function nikah_masonry_choose_column() {

	if($choose_column == 2) {
		echo 'column-2';
	}

	elseif($choose_column == 3) {
		echo 'column-3';
	}

	elseif($choose_column == 4) {
		echo 'column-4';
	}

	elseif($choose_column == 5) {
		echo 'column-5';
	}
}

add_action( 'elementor/element/image/section_image/before_section_end', function( $element, $args ) {

	$element->add_control(
		'custom_image_align',
		[
			'type' => \Elementor\Controls_Manager::SLIDER,
			'label' => __( 'Custom Image Align', 'plugin-name' ),
			'default' => [
				'size' => 0,
				'unit' => '%',
			],
			'size_units' => [ '%' ],
			'range' => [
				'%' => [
					'min' => 0,
					'max' => 100,
				],
			],
			'selectors' => [
				'{{WRAPPER}} .elementor-image img' => 'left: {{SIZE}}{{UNIT}}; position: relative;',
			],
		]
	);
}, 10, 2 );

function nikah_gallery_source() {
if('nikah-portfolio' == get_post_type()){
	$nikah_gall_sauce = array(
		'gallery_from_upload'	=> __( 'Upload or Media Library', 'nikah' ),
		'gallery_meta_box'		=> __( 'Single Portfolio Gallery', 'nikah' ),
	);
}
else {
	$nikah_gall_sauce = array(
		'gallery_from_upload'	=> __( 'Upload or Media Library', 'nikah' ),
	);
}

return $nikah_gall_sauce;
}