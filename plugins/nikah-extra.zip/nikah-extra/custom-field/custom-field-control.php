<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class nikah_portfolio_custom_fields extends Widget_Base {

	public function get_name() {
		return 'nikah-portfolio-custom-field';
	}

	public function get_title() {
		return __( 'Portfolio Custom Fields', 'nikah' );
	}

	public function get_icon() {
		return 'fa fa-plus-square';
	}

	public function get_categories() {
		return [ 'nikah-portfolio-category' ];
	}

	protected function register_controls() {

		/*===========NEWS CONTROL=============*/

		$this->start_controls_section(
			'nikah_portfolio_custom_fields_control',
			[
				'label' => __( 'Details Setting', 'nikah' ),
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => __( 'Detail Color', 'nikah' ),
				'name' => 'typography_detail1_block',
				'selector' => '{{WRAPPER}} .detail-title',
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'label' => __( 'Detail Color', 'nikah' ),
				'name' => 'typography_detail2_block',
				'selector' => '{{WRAPPER}} .detail-info',
			]
		);

		$this->add_control(
			'detail_title_color',
			[
				'label' => __( 'Detail Title Color', 'nikah' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .detail-title' => 'color: {{VALUE}};',
				],
				'default' => '#000000',
			]
		);

		$this->add_control(
			'detail_text_color',
			[
				'label' => __( 'Detail Text Color', 'nikah' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .detail-info' => 'color: {{VALUE}};',
				],
				'default' => '#000000',
			]
		);

		$gallery_columns = range( 1, 10 );
		$gallery_columns = array_combine( $gallery_columns, $gallery_columns );

		$this->add_control(
			'detail_columns',
			[
				'label' => __( 'Details Columns', 'nikah' ),
				'type' => Controls_Manager::SELECT,
				'default' => 4,
				'options' => $gallery_columns,
			]
		);

		$this->add_responsive_control(
			'detail_block_align',
			[
				'label' => __( 'Detail Alignment', 'nikah' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'nikah' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'nikah' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'nikah' ),
						'icon' => 'fa fa-align-right',
					],
					'justify' => [
						'title' => __( 'Justified', 'nikah' ),
						'icon' => 'fa fa-align-justify',
					],
				],
				'default' => 'left',
				'selectors' => [
					'{{WRAPPER}}' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

	}

	protected function render() {

		$instance = $this->get_settings();

		//$custom_text 	= ! empty( $instance['custom_text'] ) ? $instance['custom_text'] : '';

		include ( plugin_dir_path(__FILE__).'tpl/custom-field-block.php' );

	}

	protected function content_template() {}

	public function render_plain_content( $instance = [] ) {

	}

}

Plugin::instance()->widgets_manager->register_widget_type( new nikah_portfolio_custom_fields() );