<?php 
	$slider_select = $instance['slider_select']; 
?>		

<?php 
if(!empty($slider_select)) {
echo do_shortcode('[rev_slider alias="' . $slider_select . '"]');
}
wp_reset_postdata();