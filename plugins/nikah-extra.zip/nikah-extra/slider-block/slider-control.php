<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class nikah_slider extends Widget_Base {

	public function get_name() {
		return 'nikah-slider';
	}

	public function get_title() {
		return __( 'Slider Block', 'nikah' );
	}

	public function get_icon() {
		return 'eicon-slider-album';
	}

	public function get_categories() {
		return [ 'nikah-general-category' ];
	}

	protected function register_controls() {

		/*===========NEWS CONTROL=============*/

		$this->start_controls_section(
			'section_nikah_slider_general_control',
			[
				'label' => __( 'Slider Setting', 'nikah' ),
			]
		);

		$this->add_control(
			'slider_select',
			[
				'label' => __( 'Slider Post Select', 'nikah' ),
				'type' => Controls_Manager::SELECT,
				'default' => [],
				'options' => nikah_slider_temp(),
				'description' => __( 'List of your available slider template.', 'nikah' ),
			]
		);

		$this->end_controls_section();

	}

	protected function render() {

		$instance = $this->get_settings();

		include ( plugin_dir_path(__FILE__).'tpl/slider-block.php' );

	}

	protected function content_template() {}

	public function render_plain_content( $instance = [] ) {

	}

}

Plugin::instance()->widgets_manager->register_widget_type( new nikah_slider() );