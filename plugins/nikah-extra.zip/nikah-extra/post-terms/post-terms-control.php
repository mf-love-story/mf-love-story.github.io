<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class nikah_post_terms extends Widget_Base {

	public function get_name() {
		return 'nikah-terms-title';
	}

	public function get_title() {
		return __( 'Post Terms', 'nikah' );
	}

	public function get_icon() {
		return 'fa fa-sitemap';
	}

	public function get_categories() {
		return [ 'nikah-portfolio-category' ];
	}

	protected function register_controls() {

		/*===========NEWS CONTROL=============*/

		$this->start_controls_section(
			'nikah_post_terms_control',
			[
				'label' => __( 'Terms Setting', 'nikah' ),
			]
		);

		$this->add_control(
			'terms_type',
			[
				'label' => __( 'Terms Type', 'nikah' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'post_category',
				'options' => [
					'post_category' => __( 'Post Category', 'nikah' ),
					//'post_tags' => __( 'Post Tags', 'nikah' ),
				],
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography_terms_block',
				'selector' => '{{WRAPPER}} .terms-item',
			]
		);

		$this->add_control(
			'color_term_block',
			[
				'label' => __( 'Terms Text Color', 'nikah' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .terms-item' => 'color: {{VALUE}};',
				],
				'default' => '#000000',
			]
		);

		$this->add_responsive_control(
			'terms_block_align',
			[
				'label' => __( 'Title Alignment', 'nikah' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'nikah' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'nikah' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'nikah' ),
						'icon' => 'fa fa-align-right',
					],
					'justify' => [
						'title' => __( 'Justified', 'nikah' ),
						'icon' => 'fa fa-align-justify',
					],
				],
				'default' => 'left',
				'selectors' => [
					'{{WRAPPER}}' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

	}

	protected function render() {

		$instance = $this->get_settings();

		//$custom_text 	= ! empty( $instance['custom_text'] ) ? $instance['custom_text'] : '';

		include ( plugin_dir_path(__FILE__).'tpl/post-terms-block.php' );

	}

	protected function content_template() {}

	public function render_plain_content( $instance = [] ) {

	}

}

Plugin::instance()->widgets_manager->register_widget_type( new nikah_post_terms() );