<?php
namespace Elementor;

if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class nikah_post_date extends Widget_Base {

	public function get_name() {
		return 'nikah-post-date';
	}

	public function get_title() {
		return __( 'Post Date', 'nikah' );
	}

	public function get_icon() {
		return 'fa fa-clock-o';
	}

	public function get_categories() {
		return [ 'nikah-portfolio-category' ];
	}

	protected function register_controls() {

		/*===========NEWS CONTROL=============*/

		$this->start_controls_section(
			'nikah_post_date_control',
			[
				'label' => __( 'Date Setting', 'nikah' ),
			]
		);

		$this->add_control(
			'date_type',
			[
				'label' => __( 'Date Type', 'nikah' ),
				'type' => Controls_Manager::SELECT,
				'default' => 'publish',
				'options' => [
					'publish' => __( 'Publish Date', 'nikah' ),
					'modify' => __( 'Modify Date', 'nikah' ),
				]
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name' => 'typography_date_block',
				'selector' => '{{WRAPPER}} .post-date',
			]
		);

		$this->add_control(
			'color_text_block',
			[
				'label' => __( 'Date Color', 'nikah' ),
				'type' => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .post-date' => 'color: {{VALUE}};',
				],
				'default' => '#000000',
			]
		);

		$this->add_responsive_control(
			'text_block_align',
			[
				'label' => __( 'Title Alignment', 'nikah' ),
				'type' => Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => __( 'Left', 'nikah' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => __( 'Center', 'nikah' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => __( 'Right', 'nikah' ),
						'icon' => 'fa fa-align-right',
					],
					'justify' => [
						'title' => __( 'Justified', 'nikah' ),
						'icon' => 'fa fa-align-justify',
					],
				],
				'default' => 'left',
				'selectors' => [
					'{{WRAPPER}}' => 'text-align: {{VALUE}};',
				],
				'separator' => 'before',
			]
		);

		$this->end_controls_section();

	}

	protected function render() {

		$instance = $this->get_settings();

		$date_type 	= ! empty( $instance['date_type'] ) ? $instance['date_type'] : 'publish';

		include ( plugin_dir_path(__FILE__).'tpl/post-date-block.php' );

	}

	protected function content_template() {}

	public function render_plain_content( $instance = [] ) {

	}

}

Plugin::instance()->widgets_manager->register_widget_type( new nikah_post_date() );