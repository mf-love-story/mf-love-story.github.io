<div class="nikah-text clearfix">
<?php 
	echo balancetags($custom_text);
?>
</div>